import pandas as pd
import numpy as np
from sklearn.model_selection import train_test_split

  #  Names of the columns in the dataset

ROWS = [
    [
        "Col1",
        "Col2",
        "Col3",
        "Col4",
        "Col5",
        "Col6",
        "Col7",
        "Col8",
        "Col9",
        "Col10",
        "Col11",
        "Col12",
    ],
    [
        "Col1",
        "Col2",
        "Col3",
        "Col4",
        "Col5",
        "Col6",
        "Col7",
        "Col8",
        "Col9",
        "Col10",
        "Col11",
        "Col12",
    ],
    
]


  #  Remove the data points with abrupt values


def remove_outliers(data):
    stats = []
    new_data = []
    for col in ROWS[0]:
        sd_feature = data[col].std()
        mean_feature = data[col].mean()
        stats.append((mean_feature, sd_feature))

    for idx, row in data.iterrows():
        take = True
        for i in range(1, len(row) - 1):
            mean, sd = stats[i - 1]
            if row[i] > 2*mean + 5* sd or row[i] < 2*mean - 5 * sd:
                take = False
                break
        if take:
            new_data.append(row)
    return pd.DataFrame(new_data)

  #  Normalize some attribute values


def normalize_features(data):
    ROWS_normalize = [
        "Col1",
        "Col2",
        "Col3",
        "Col4",
        "Col5",
        "Col6",
        "Col7",
        "Col8",
        "Col9",
        "Col10",
        "Col11",
        "Col12",
    ]
    for col in ROWS[0]:
        if col in ROWS_normalize:
            data[col] = data[col] / (data[col].max() - data[col].min())
    return data

  #  Segregate the classes in the dataset according to the Response (0 or 1)

def class_segregation(X_train, y_train):
    segregate_classes = {}
    for idx, row in X_train.iterrows():
        class_value = y_train[idx]
        if class_value not in segregate_classes:
            segregate_classes[class_value] = []
        segregate_classes[class_value].append(row)
    return segregate_classes

  #  Calculate the mean and standard deviation of each attribute in the dataset

def statistics_data(X_train):
    as_df = pd.DataFrame(X_train)
    stats = []
    for col in ROWS[0]:
        if col in ROWS[1]:
            stats.append((len(as_df[col]), as_df[col].mean(), as_df[col].std()))
        else:
            stat_per_val = {}
            for val in as_df[col].unique():
                stat_per_val[val] = as_df[as_df[col] == val][col].count()
            stats.append((len(as_df[col]), stat_per_val))
    return stats

  #  Calculate the mean and standard deviation of each class_att values

def class_statistics(X_train, y_train):
    class_segregate = class_segregation(X_train, y_train)
    stats = {}
    for class_value, rows in class_segregate.items():
        stats[class_value] = statistics_data(rows)
    return stats

  #  Split the dataset into 5 folds

def split_cross_validation(X_train, folds):
    X_train = X_train.sample(frac=1)
    splits = []
    for i in range(folds):
        splits.append(
            X_train.iloc[i * len(X_train) // folds : (i + 1) * len(X_train) // folds]
        )
    return splits

    # Apply the naive bayes algorithm on the dataset

def naive_bayes(X_train, y_train, X_test):
    class_stats = class_statistics(X_train, y_train)
    prob_row = calc_probability_class(class_stats, X_test)
    return prob_row, class_stats

   # Calculate the accuracy of the model, using the predicted outputs and the actual outputs

def accuracy_score(y_test, predictions):
    works = 0
    y_test = y_test.to_numpy()
    for i in range(len(predictions)):
        prob = predictions[i]
        if prob[0] > prob[1] and y_test[i] == 0:
            works += 1
        elif prob[0] < prob[1] and y_test[i] == 1:
            works += 1
    return works * 100 / len(predictions)

 #   Calculate the probability of occurrence of a data value using Gaussian Naive Bayes

def probability_calculate_gnb(x, mean, sd):
    exponent = np.exp(-(((x - mean) / sd) ** 2 / float(2)))
    return (1 / (np.sqrt(2 * np.pi) * sd)) * exponent

  #  Calculate the probability of occurrence of a data value using Naive Bayes


def probability_calculate_nb(x, tot, stat):
    return stat[x] / float(tot)

   # Calculate the probability of occurrence of each data point in each class


def calc_probability_class(class_stats, X_test):
    total_sample_size = sum(
        [class_stats[class_value][0][0] for class_value in class_stats]
    )
    prob_row = []
    for idx, row in X_test.iterrows():
        probabilities = {}
        for class_value, stats_data in class_stats.items():
            probabilities[class_value] = stats_data[0][0] / total_sample_size

            for i in range(len(stats_data)):
                if ROWS[0][i] in ROWS[1]:
                    count, mean, sd = stats_data[i]
                    probabilities[class_value] *= probability_calculate_gnb(
                        row[i + 1], mean, sd
                    )
                else:
                    tot, stat = stats_data[i]
                    probabilities[class_value] *= probability_calculate_nb(
                        row[i + 1], tot, stat
                    )
        prob_row.append(probabilities)
    return prob_row

   # Create the k-fold cross validation model, uses naive bayes algorithm, and split the dataset into 10 folds

def naive_bayes_with_k_fold(X_train, folds, y_train):
    new_data = X_train.assign(Response=y_train)
    splits = split_cross_validation(new_data, folds)
    split_Class = []
    for split in splits:
        split_Class.append(split["Class_att"])
        split.drop(["Class_att"], axis=1, inplace=True)
    best_accuracy = -1
    best_summary = None

    for fold in range(folds):
        X_test = splits[fold]
        # print((X_test))
        X_train = pd.concat([splits[i] for i in range(folds) if i != fold])
        y_train = pd.concat([split_Class[i] for i in range(folds) if i != fold])
        y_test = split_Class[fold]
        prediction, summary = naive_bayes(X_train, y_train, X_test)
        accuracy = accuracy_score(y_test, prediction)
        if accuracy > best_accuracy:
            best_accuracy = accuracy
            best_summary = summary

    # print(best_summary, best_accuracy)
    return best_summary


def main():
    d_type = {
        "Col1" : int,
        "Col2" : int,
        "Col3" : int,
        "Col4" : int,
        "Col5" : int,
        "Col6" : int,
        "Col7" : int,
        "Col8" : int,
        "Col9" : int,
        "Col10" : int,
        "Col11" : int,
        "Col12" : int,
        "Class_att" : "string",
    
    }
    file = open("Train_D_Bayesian.csv", "r")
    data = pd.read_csv(file, useROWS=d_type)

   # Change the values of Abnormal and normal into boolean
    data.replace('Abnormal', 0, inplace=True)
    data.replace('Normal', 1, inplace= True)

    

    data = remove_outliers(data)



    X_train, X_test, y_train, y_test = train_test_split(
        data.drop(['Class_att'], axis = 1), data["Class_att"], test_size=0.3, random_state=0
    )

    normalize_features(X_train)
    normalize_features(X_test)

    n_folds = 5
    best_summary = naive_bayes_with_k_fold(X_train, n_folds, y_train)
    y_test = pd.DataFrame(y_test)

    prob_row = calc_probability_class(best_summary, X_test)
    accuracy = accuracy_score(y_test, prob_row)
    print(accuracy)


if __name__ == "__main__":
    main()
